#!/usr/bin/env python3
"""
LexiGraphe — Serveur Flask

Version serveur du jeu "Chaîne Sémantique" avec :
- API REST pour le jeu
- Stockage SQLite des relations collectées
- Export des données pour analyse
- Extraction des relations depuis le TLFi (dérivés, domaines)
"""

import json
import random
import sqlite3
import re
from datetime import datetime
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory, render_template
from flask_cors import CORS

# ========================================
# CONFIGURATION
# ========================================

app = Flask(__name__, template_folder='templates')
CORS(app)

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR.parent / "data"
DB_PATH = DATA_DIR / "lexigraphe.db"

# ========================================
# BASE DE DONNÉES
# ========================================

def get_db():
    """Connexion à la base SQLite."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initialise la base de données."""
    conn = get_db()
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS relations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word_from TEXT NOT NULL,
            word_to TEXT NOT NULL,
            player_id TEXT,
            context TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            validated INTEGER DEFAULT 0,
            votes_up INTEGER DEFAULT 0,
            votes_down INTEGER DEFAULT 0
        );
        
        CREATE TABLE IF NOT EXISTS chains (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player_id TEXT,
            start_word TEXT NOT NULL,
            end_word TEXT NOT NULL,
            chain_json TEXT NOT NULL,
            length INTEGER NOT NULL,
            score INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS players (
            id TEXT PRIMARY KEY,
            nickname TEXT,
            total_score INTEGER DEFAULT 0,
            chains_completed INTEGER DEFAULT 0,
            relations_contributed INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE INDEX IF NOT EXISTS idx_relations_words ON relations(word_from, word_to);
        CREATE INDEX IF NOT EXISTS idx_relations_validated ON relations(validated);
    ''')
    conn.commit()
    conn.close()


# ========================================
# LEXIQUE
# ========================================

LEXICON = {}
LEXICON_KEYS = []  # Liste des clés pour sélection aléatoire
LEXICON_KEYS_UPPER = {}  # Mapping majuscule → clé réelle

def load_lexicon():
    """Charge le lexique depuis le fichier JSON."""
    global LEXICON, LEXICON_KEYS, LEXICON_KEYS_UPPER
    
    lexicon_path = DATA_DIR / "tlfi_complet.json"#changer si nécessaire
    if not lexicon_path.exists():
        print(f"⚠️  Fichier lexique non trouvé : {lexicon_path}")
        return {}
    
    with open(lexicon_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
        LEXICON = data.get('entries', {})
    
    # Construire les index
    LEXICON_KEYS = list(LEXICON.keys())
    LEXICON_KEYS_UPPER = {k.upper(): k for k in LEXICON_KEYS}
    
    return LEXICON


def normalize_word(word):
    """Normalise un mot pour la recherche (majuscules, accents conservés)."""
    return word.upper().strip()


def find_entry(word):
    """Trouve une entrée dans le lexique (insensible à la casse)."""
    word_upper = normalize_word(word)
    
    # Correspondance exacte en majuscules
    if word_upper in LEXICON_KEYS_UPPER:
        real_key = LEXICON_KEYS_UPPER[word_upper]
        return LEXICON.get(real_key)
    
    # Correspondance directe
    if word in LEXICON:
        return LEXICON[word]
    
    return None


def extract_definitions(entry):
    """Extrait les définitions d'une entrée (format v1 ou v2)."""
    definitions = []
    
    # Format v2 (hiérarchique)
    if 'senses' in entry:
        for sense in entry['senses']:
            if sense.get('definition'):
                definitions.append(sense['definition'])
            for subsense in sense.get('subsenses', []):
                if subsense.get('definition'):
                    definitions.append(subsense['definition'])
    
    # Format v1 (plat)
    if 'definitions' in entry:
        definitions.extend(entry['definitions'])
    
    return definitions


def extract_domains(entry):
    """Extrait les domaines d'une entrée."""
    domains = set()
    
    # Format v2
    if 'senses' in entry:
        for sense in entry['senses']:
            if sense.get('domain'):
                domains.add(sense['domain'])
            for subsense in sense.get('subsenses', []):
                if subsense.get('domain'):
                    domains.add(subsense['domain'])
    
    # Format v1
    if 'domains' in entry:
        domains.update(entry['domains'])
    
    return list(domains)


def extract_derivatives(entry):
    """Extrait les dérivés d'une entrée."""
    derivatives = []
    
    if 'derivatives' in entry:
        for deriv in entry['derivatives']:
            if isinstance(deriv, dict):
                lemma = deriv.get('lemma', '')
            else:
                lemma = deriv
            if lemma:
                # Vérifier que le dérivé existe dans le lexique
                if find_entry(lemma):
                    derivatives.append(normalize_word(lemma))
    
    return derivatives


def get_words_by_domain(domain, limit=10):
    """Trouve des mots du même domaine."""
    words = []
    domain_upper = domain.upper()
    
    for key, entry in LEXICON.items():
        entry_domains = extract_domains(entry)
        for d in entry_domains:
            if d.upper() == domain_upper:
                words.append(key)
                if len(words) >= limit:
                    return words
                break
    
    return words


def get_crowdsourced_relations(word):
    """Récupère les relations crowdsourcées validées."""
    word_upper = normalize_word(word)
    relations = set()
    
    conn = get_db()
    cursor = conn.execute('''
        SELECT word_to FROM relations 
        WHERE UPPER(word_from) = ? AND (validated = 1 OR votes_up > votes_down + 2)
        UNION
        SELECT word_from FROM relations 
        WHERE UPPER(word_to) = ? AND (validated = 1 OR votes_up > votes_down + 2)
    ''', (word_upper, word_upper))
    
    for row in cursor:
        # Vérifier que le mot existe dans le lexique
        if find_entry(row[0]):
            relations.add(normalize_word(row[0]))
    
    conn.close()
    return list(relations)


def get_all_relations(word):
    """Récupère toutes les relations d'un mot (dérivés + domaine + crowdsourcées)."""
    entry = find_entry(word)
    if not entry:
        return []
    
    relations = set()
    
    # Dérivés morphologiques
    derivatives = extract_derivatives(entry)
    relations.update(derivatives)
    
    # Relations crowdsourcées
    crowdsourced = get_crowdsourced_relations(word)
    relations.update(crowdsourced)
    
    # Exclure le mot lui-même
    word_upper = normalize_word(word)
    relations.discard(word_upper)
    
    return list(relations)


def are_related(word1, word2):
    """Vérifie si deux mots sont liés."""
    word1_upper = normalize_word(word1)
    word2_upper = normalize_word(word2)
    
    # Vérifier les dérivés
    entry1 = find_entry(word1)
    if entry1:
        derivatives = extract_derivatives(entry1)
        if word2_upper in derivatives:
            return True
    
    entry2 = find_entry(word2)
    if entry2:
        derivatives = extract_derivatives(entry2)
        if word1_upper in derivatives:
            return True
    
    # Vérifier les domaines communs
    if entry1 and entry2:
        domains1 = set(d.upper() for d in extract_domains(entry1))
        domains2 = set(d.upper() for d in extract_domains(entry2))
        if domains1 & domains2:  # Intersection non vide
            return True
    
    # Vérifier les relations crowdsourcées
    conn = get_db()
    cursor = conn.execute('''
        SELECT COUNT(*) FROM relations 
        WHERE ((UPPER(word_from) = ? AND UPPER(word_to) = ?) 
               OR (UPPER(word_from) = ? AND UPPER(word_to) = ?))
        AND (validated = 1 OR votes_up > votes_down)
    ''', (word1_upper, word2_upper, word2_upper, word1_upper))
    
    count = cursor.fetchone()[0]
    conn.close()
    
    return count > 0


def generate_challenge():
    """Génère un défi avec des mots qui existent vraiment dans le lexique."""
    if len(LEXICON_KEYS) < 2:
        return None, None
    
    # Critères pour un bon mot de départ/arrivée :
    # - A des dérivés (pour avoir des voisins)
    # - Pas trop long
    # - Domaine identifié (pour permettre des connexions)
    
    good_words = []
    
    for key in LEXICON_KEYS:
        entry = LEXICON[key]
        
        # Vérifier qu'il a des dérivés ou un domaine
        derivatives = extract_derivatives(entry)
        domains = extract_domains(entry)
        
        if (len(derivatives) >= 1 or len(domains) >= 1) and len(key) <= 12:
            good_words.append(key)
    
    if len(good_words) < 2:
        # Fallback : n'importe quels mots
        good_words = LEXICON_KEYS[:1000]  # Limiter pour la performance
    
    # Choisir deux mots différents
    start = random.choice(good_words)
    end = random.choice([w for w in good_words if w != start])
    
    return normalize_word(start), normalize_word(end)


# ========================================
# ROUTES API
# ========================================

@app.route('/')
def index():
    """Page d'accueil — sert le template HTML."""
    return render_template('index.html')


@app.route('/api/challenge', methods=['GET'])
def get_challenge():
    """Génère un nouveau défi."""
    start, end = generate_challenge()
    
    if not start or not end:
        return jsonify({'error': 'Lexique vide'}), 500
    
    return jsonify({
        'start': start,
        'end': end
    })


@app.route('/api/word/<word>', methods=['GET'])
def get_word_info(word):
    """Récupère les informations sur un mot."""
    entry = find_entry(word)
    
    if not entry:
        return jsonify({'error': 'Mot non trouvé', 'word': word}), 404
    
    word_normalized = normalize_word(word)
    
    return jsonify({
        'word': word_normalized,
        'pos': entry.get('pos', ''),
        'definitions': extract_definitions(entry),
        'domains': extract_domains(entry),
        'derivatives': extract_derivatives(entry),
        'relations': get_all_relations(word)
    })


@app.route('/api/check-relation', methods=['POST'])
def check_relation():
    """Vérifie si deux mots sont liés."""
    data = request.json
    word1 = data.get('from', '')
    word2 = data.get('to', '')
    
    if not word1 or not word2:
        return jsonify({'error': 'Mots manquants'}), 400
    
    word1_norm = normalize_word(word1)
    word2_norm = normalize_word(word2)
    
    is_known = are_related(word1, word2)
    
    return jsonify({
        'from': word1_norm,
        'to': word2_norm,
        'known_relation': is_known,
        'message': 'Relation connue' if is_known else 'Nouvelle relation proposée'
    })


@app.route('/api/submit-relation', methods=['POST'])
def submit_relation():
    """Enregistre une nouvelle relation proposée par un joueur."""
    data = request.json
    word_from = normalize_word(data.get('from', ''))
    word_to = normalize_word(data.get('to', ''))
    player_id = data.get('player_id', 'anonymous')
    context = data.get('context', '')
    
    if not word_from or not word_to:
        return jsonify({'error': 'Mots manquants'}), 400
    
    conn = get_db()
    
    # Vérifier si la relation existe déjà
    cursor = conn.execute('''
        SELECT id, votes_up FROM relations 
        WHERE UPPER(word_from) = ? AND UPPER(word_to) = ?
    ''', (word_from, word_to))
    
    existing = cursor.fetchone()
    
    if existing:
        # Incrémenter le vote
        conn.execute('UPDATE relations SET votes_up = votes_up + 1 WHERE id = ?', 
                    (existing['id'],))
        conn.commit()
        conn.close()
        return jsonify({
            'status': 'reinforced',
            'message': f'Relation {word_from} → {word_to} renforcée'
        })
    else:
        # Créer une nouvelle relation
        conn.execute('''
            INSERT INTO relations (word_from, word_to, player_id, context)
            VALUES (?, ?, ?, ?)
        ''', (word_from, word_to, player_id, context))
        conn.commit()
        conn.close()
        return jsonify({
            'status': 'created',
            'message': f'Nouvelle relation {word_from} → {word_to} enregistrée'
        })


@app.route('/api/submit-chain', methods=['POST'])
def submit_chain():
    """Enregistre une chaîne complétée."""
    data = request.json
    chain = data.get('chain', [])
    player_id = data.get('player_id', 'anonymous')
    
    if len(chain) < 2:
        return jsonify({'error': 'Chaîne trop courte'}), 400
    
    # Normaliser la chaîne
    chain = [normalize_word(w) for w in chain]
    
    start_word = chain[0]
    end_word = chain[-1]
    length = len(chain) - 1
    
    # Calculer le score
    base_points = 100
    bonus = max(0, (10 - length) * 20)
    score = base_points + bonus
    
    # Enregistrer la chaîne
    conn = get_db()
    conn.execute('''
        INSERT INTO chains (player_id, start_word, end_word, chain_json, length, score)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (player_id, start_word, end_word, json.dumps(chain), length, score))
    
    # Enregistrer toutes les relations de la chaîne
    new_relations = 0
    for i in range(len(chain) - 1):
        word_from = chain[i]
        word_to = chain[i + 1]
        
        # Vérifier si c'est une nouvelle relation
        cursor = conn.execute('''
            SELECT id FROM relations WHERE UPPER(word_from) = ? AND UPPER(word_to) = ?
        ''', (word_from, word_to))
        
        if not cursor.fetchone():
            conn.execute('''
                INSERT INTO relations (word_from, word_to, player_id, context)
                VALUES (?, ?, ?, ?)
            ''', (word_from, word_to, player_id, f'chain:{start_word}->{end_word}'))
            new_relations += 1
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'status': 'success',
        'score': score,
        'length': length,
        'new_relations': new_relations,
        'message': f'Chaîne enregistrée ! {score} points'
    })


@app.route('/api/leaderboard', methods=['GET'])
def get_leaderboard():
    """Récupère le classement des joueurs."""
    conn = get_db()
    cursor = conn.execute('''
        SELECT player_id, SUM(score) as total_score, COUNT(*) as chains_count
        FROM chains
        GROUP BY player_id
        ORDER BY total_score DESC
        LIMIT 10
    ''')
    
    leaderboard = []
    for row in cursor:
        leaderboard.append({
            'player_id': row['player_id'],
            'score': row['total_score'],
            'chains': row['chains_count']
        })
    
    conn.close()
    return jsonify(leaderboard)


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Statistiques générales du jeu."""
    conn = get_db()
    
    # Nombre de relations
    cursor = conn.execute('SELECT COUNT(*) FROM relations')
    relations_count = cursor.fetchone()[0]
    
    # Nombre de relations validées
    cursor = conn.execute('SELECT COUNT(*) FROM relations WHERE validated = 1 OR votes_up > votes_down + 2')
    validated_count = cursor.fetchone()[0]
    
    # Nombre de chaînes
    cursor = conn.execute('SELECT COUNT(*) FROM chains')
    chains_count = cursor.fetchone()[0]
    
    # Chaîne la plus courte par défi
    cursor = conn.execute('''
        SELECT start_word, end_word, MIN(length) as min_length
        FROM chains
        GROUP BY start_word, end_word
        ORDER BY min_length ASC
        LIMIT 10
    ''')
    best_chains = []
    for row in cursor:
        best_chains.append({
            'start': row['start_word'],
            'end': row['end_word'],
            'best_length': row['min_length']
        })
    
    conn.close()
    
    return jsonify({
        'lexicon_size': len(LEXICON),
        'total_relations': relations_count,
        'validated_relations': validated_count,
        'total_chains': chains_count,
        'best_chains': best_chains
    })


@app.route('/api/export/relations', methods=['GET'])
def export_relations():
    """Exporte toutes les relations collectées (pour analyse)."""
    conn = get_db()
    cursor = conn.execute('''
        SELECT word_from, word_to, votes_up, votes_down, validated, created_at
        FROM relations
        ORDER BY votes_up DESC
    ''')
    
    relations = []
    for row in cursor:
        relations.append({
            'from': row['word_from'],
            'to': row['word_to'],
            'votes_up': row['votes_up'],
            'votes_down': row['votes_down'],
            'validated': bool(row['validated']),
            'created_at': row['created_at']
        })
    
    conn.close()
    
    return jsonify({
        'export_date': datetime.now().isoformat(),
        'count': len(relations),
        'relations': relations
    })


@app.route('/api/search', methods=['GET'])
def search_words():
    """Recherche de mots dans le lexique."""
    query = request.args.get('q', '').upper().strip()
    limit = min(int(request.args.get('limit', 20)), 100)
    
    if len(query) < 2:
        return jsonify({'results': []})
    
    results = []
    for key in LEXICON_KEYS:
        if query in key.upper():
            results.append(key)
            if len(results) >= limit:
                break
    
    return jsonify({'results': results})


# ========================================
# MAIN
# ========================================

if __name__ == '__main__':
    # Initialiser la base de données
    DATA_DIR.mkdir(exist_ok=True)
    init_db()
    
    # Charger le lexique
    load_lexicon()
    
    if not LEXICON:
        print("⚠️  Lexique non trouvé ou vide.")
        print(f"   Attendu : {DATA_DIR / 'tlfi_complet.json'}")#changer si nécessaire
        print("   Exécutez d'abord les scripts de conversion.")
    else:
        print(f"✓ Lexique chargé : {len(LEXICON)} entrées")
    
    print(f"✓ Base de données : {DB_PATH}")
    print("✓ Serveur démarré sur http://localhost:5000")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
