# LexiGraphe: construire des Chaînes Sémantiques

**Jeu lexical collaboratif basé sur le TLFi**

Reliez des mots par des chaînes sémantiques et contribuez à enrichir un graphe de relations lexicales.


---

## Concept du jeu

**Objectif** : Relier deux mots éloignés (ex. LIGNIFIER → GLACE) par une chaîne de mots intermédiaires, chaque maillon étant sémantiquement lié au précédent.

**Exemple** :
```
LIGNIFIER → BOIS → FORÊT → OMBRE → FRAÎCHEUR → GLACE
```

**Scoring** : Moins de maillons = meilleur score.

**Collecte** : Chaque maillon proposé enrichit un graphe de relations sémantiques. Les relations validées par plusieurs joueurs sont intégrées à la base.

---

## Structure du projet

```
lexigraphe/
├── standalone/                    # Version JavaScript autonome
│   └── index.html                 # Jeu complet en un seul fichier
├── server/                        # Version Flask avec API
│   └── app.py                     # Serveur Python
├── scripts/                       # Outils de traitement
│   ├── tlfi_to_json.py            # Convertisseur v1 (format plat)
│   ├── tlfi_to_json_v2.py         # Convertisseur v2 (format hiérarchique)
│   ├── merge_tlfi_json.py         # Fusion de plusieurs JSON
│   └── convert_and_merge_tlfi.sh  # Script complet conversion + fusion
├── data/                          # Données
│   └── tlfi_sample.json           # Lexique (à générer)
├── requirements.txt               # Dépendances Python
└── README.md
```

---

## Conversion du TLFi (étape préalable)

Le TLFi est distribué en **81 fichiers XML**. Deux méthodes sont possibles :

### Méthode 1 — Script automatique (recommandé)

```bash
cd lexigraphe

# Rendre le script exécutable
chmod +x scripts/convert_and_merge_tlfi.sh

# Lancer la conversion + fusion
./scripts/convert_and_merge_tlfi.sh /chemin/vers/tlfi_xml/ data/
```

Ce script :
1. Convertit chaque fichier XML en JSON (dans `data/json_parts/`)
2. Fusionne tous les JSON en un seul fichier `data/tlfi_complet.json`
3. Utilise le mode streaming pour économiser la mémoire

Résultat :
```
data/
├── json_parts/          # 81 fichiers JSON individuels (supprimables)
└── tlfi_complet.json    # Fichier fusionné final
```

### Méthode 2: Étapes manuelles

#### Étape 2a: Convertir chaque fichier XML

```bash
# Convertir tous les XML d'un dossier
for xml in /chemin/vers/tlfi_xml/*.xml; do
    python scripts/tlfi_to_json_v2.py "$xml" "data/json_parts/$(basename "$xml" .xml).json"
done
```

#### Étape 2b: Fusionner les JSON

```bash
# Mode streaming (économe en mémoire, recommandé)
python scripts/merge_tlfi_json.py data/json_parts/ data/tlfi_complet.json --streaming

# Ou mode mémoire (plus rapide si vous avez assez de RAM)
python scripts/merge_tlfi_json.py data/json_parts/ data/tlfi_complet.json
```

### Méthode 3: Fichier unique (si RAM suffisante)

```bash
python scripts/tlfi_to_json_v2.py /chemin/vers/tlfi_unique.xml data/tlfi_sample.json
```

### Vérifier la conversion

```bash
# Nombre d'entrées
python -c "import json; d=json.load(open('data/tlfi_complet.json')); print(f'{len(d[\"entries\"])} entrées')"

# Afficher une entrée
python -c "import json; d=json.load(open('data/tlfi_complet.json')); print(json.dumps(d['entries']['LIMER'], indent=2, ensure_ascii=False))"
```

### Renommer pour le serveur

Le serveur Flask cherche par défaut `data/tlfi_complet.json` :

---

## Installation et utilisation

### Mode 1: Standalone (sans serveur)

Ouvrez simplement `standalone/index.html` dans un navigateur.

```bash
# Linux/Mac
xdg-open standalone/index.html
# ou
open standalone/index.html

# Windows
start standalone/index.html
```

**Avantages** :
- Aucune installation requise
- Fonctionne hors ligne
- Idéal pour les démos

**Limitations** :
- Données non persistantes (perdues à la fermeture)
- Lexique limité (intégré dans le HTML)

---

### Mode 2: Serveur Flask (installation locale)

#### Prérequis

- Python 3.8 ou supérieur
- Le fichier JSON du TLFi (produit par le script de conversion)

#### Étape 1 — Cloner ou télécharger le projet

```bash
# Télécharger et décompresser l'archive
unzip lexigraphe.zip
cd lexigraphe
```

#### Étape 2 — Créer un environnement virtuel (recommandé)

```bash
# Créer l'environnement
python3 -m venv lexigraph

# Activer l'environnement
# Linux / macOS :
source lexigraph/bin/activate
# Windows :
lexigraph\Scripts\activate
```

#### Étape 3 — Installer les dépendances

```bash
pip install -r requirements.txt
```

Ou manuellement :

```bash
pip install flask flask-cors lxml
```

#### Étape 4 — Placer le fichier JSON du TLFi

Copiez votre fichier JSON converti dans le dossier `data/` :

```bash
cp /chemin/vers/tlfi.json data/tlfi_sample.json
```

> **Note** : Le serveur cherche par défaut le fichier `data/tlfi_complet.json`. Vous pouvez modifier ce chemin dans `server/app.py` (variable `DATA_DIR`).

#### Étape 5: Lancer le serveur

```bash
cd server
python app.py
```

Vous devriez voir :

```
✓ Lexique chargé : 54321 entrées
✓ Base de données : /chemin/vers/lexigraphe/data/lexigraphe.db
✓ Serveur démarré sur http://localhost:5000
```

#### Étape 6: Jouer

Ouvrez votre navigateur à l'adresse : **http://localhost:5000**

---

#### Résumé des commandes (copier-coller)

```bash
# Installation complète en une fois
unzip lexigraphe.zip && cd lexigraphe
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp /chemin/vers/tlfi.json data/tlfi_sample.json
cd server && python app.py
```

---

#### Arrêter le serveur

Appuyez sur `Ctrl+C` dans le terminal.

Pour relancer plus tard :

```bash
cd lexigraphe
source venv/bin/activate  # réactiver l'environnement
cd server && python app.py
```

---

**Avantages de la version serveur** :
- Stockage SQLite des relations collectées par les joueurs
- API REST pour intégrations externes
- Export des données pour analyse linguistique
- Classement des joueurs
- Persistance entre les sessions

---

## API REST (mode serveur)

| Endpoint | Méthode | Description |
|----------|---------|-------------|
| `/api/challenge` | GET | Génère un nouveau défi (paire de mots) |
| `/api/word/<mot>` | GET | Informations sur un mot (définition, relations) |
| `/api/check-relation` | POST | Vérifie si deux mots sont liés |
| `/api/submit-relation` | POST | Enregistre une nouvelle relation |
| `/api/submit-chain` | POST | Enregistre une chaîne complétée |
| `/api/leaderboard` | GET | Classement des joueurs |
| `/api/stats` | GET | Statistiques du jeu |
| `/api/export/relations` | GET | Export JSON des relations collectées |

### Exemples

```bash
# Obtenir un défi
curl http://localhost:5000/api/challenge

# Informations sur un mot
curl http://localhost:5000/api/word/BOIS

# Soumettre une chaîne
curl -X POST http://localhost:5000/api/submit-chain \
  -H "Content-Type: application/json" \
  -d '{"chain": ["LIGNIFIER", "BOIS", "FORÊT", "OMBRE", "GLACE"]}'
```

---

## Conversion du TLFi

Le script `tlfi_to_json.py` convertit les fichiers XML du TLFi en JSON exploitable.

Télécharger la version XML du TLFi sur (https://www.ortolang.fr/market/lexicons/xml-tlfi/v1).

```bash
# Avec un fichier TLFi complet
python scripts/tlfi_to_json.py /chemin/vers/tlfi_complet.xml data/tlfi.json

# Génération de données d'exemple (sans fichier TLFi)
python scripts/tlfi_to_json.py
```

### Format JSON produit

```json
{
  "metadata": {
    "source": "TLFi (ATILF)",
    "entries_count": 100000,
    "format_version": "1.0"
  },
  "entries": {
    "LIGNIFIER": {
      "id": "tlfi_lignifier",
      "lemma": "LIGNIFIER",
      "pos": "verbe pronominal",
      "domains": ["BOT."],
      "definitions": ["Se transformer en bois."],
      "examples": ["Les rejets à peine nés..."],
      "derivatives": ["LIGNIFIÉ", "LIGNIFICATION"],
      "etymology_roots": ["lignum"]
    }
  }
}
```

---

## Intérêt pédagogique (Master LIIAN)

Ce projet illustre plusieurs compétences enseignées dans le master :

| Compétence | Illustration dans le projet |
|------------|----------------------------|
| **XML / XSLT** | Parsing du TLFi, extraction structurée |
| **Python** | Scripts de conversion, API Flask |
| **JavaScript** | Interface de jeu interactive |
| **Bases de données** | SQLite pour le stockage des relations |
| **TAL** | Exploitation des relations sémantiques |
| **Crowdsourcing** | Collecte de données linguistiques par le jeu |
| **Accessibilité et inclusion numérique** | Enrichissement du TLFi, présentation graphique des relations lexicales |

---

## Exploitation des données collectées

Les relations collectées par les joueurs peuvent servir à :

1. **Enrichir le TLFi**: Ajout de relations sémantiques telles que synonymes, antonymes, hyperonymes, hyponymes, termes associés, etc.
2. **Entraîner des embeddings**: Retrofitting avec les relations validées
3. **Évaluer la difficulté lexicale**: Mots peu reliés = mots rares/techniques
4. **Détecter les confusions**: Relations fréquentes mais incorrectes = faux-amis

### Export pour analyse

```python
import requests
import json

# Récupérer les relations
response = requests.get('http://localhost:5000/api/export/relations')
relations = response.json()['relations']

# Filtrer les relations validées
validated = [r for r in relations if r['votes_up'] > r['votes_down'] + 2]

# Construire un graphe
import networkx as nx
G = nx.DiGraph()
for r in validated:
    G.add_edge(r['from'], r['to'], weight=r['votes_up'])
```

---

## Développement

### Prérequis

- Python 3.8+
- Navigateur moderne (Chrome, Firefox, Safari, Edge)

### Dépendances Python

```bash
pip install -r requirements.txt
```

### Tests

```bash
# Lancer le serveur en mode debug
python server/app.py

# Tester l'API
curl http://localhost:5000/api/stats
```

---

## TODO

- [ ] Validation des relations par embeddings (similarité cosinus)
- [ ] Mode multijoueur temps réel (WebSocket)
- [ ] Statistiques par joueur
- [ ] Export vers formats standards (RDF, WordNet)
- [ ] Accessibilité RGAA niveau AA
- [ ] Internationalisation (interface en anglais)

---

##  Licence

Données lexicales : [TLFi - ATILF](http://www.atilf.fr/tlfi) (Copyright ATILF - CNRS - Université de Lorraine)

Code : MIT

---

## Crédits

Projet développé dans le cadre du **Master LIIAN** (Linguistique Informatique pour l'Inclusion et l'Accessibilité Numérique), Université de Lille et UMR STL 8163.

Inspiré par :

- [JeuxDeMots](http://www.jeuxdemots.org/) (LIRMM)
- [Semantris](https://research.google.com/semantris/) (Google)
