#!/bin/bash
#
# convert_and_merge_tlfi.sh
#
# Convertit tous les fichiers XML du TLFi en JSON, puis fusionne le tout.
#
# Usage :
#   ./convert_and_merge_tlfi.sh /chemin/vers/xml/ /chemin/vers/sortie/
#
# Exemple :
#   ./convert_and_merge_tlfi.sh ~/tlfi_xml/ ~/lexigraphe/data/
#
# Produit :
#   - Un fichier JSON par fichier XML dans un sous-dossier temporaire
#   - Un fichier tlfi_complet.json fusionné
#

set -e  # Arrêter en cas d'erreur

# === CONFIGURATION ===
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONVERTER="$SCRIPT_DIR/tlfi_to_json_v2.py"
MERGER="$SCRIPT_DIR/merge_tlfi_json.py"

# === ARGUMENTS ===
if [ $# -lt 2 ]; then
    echo "Usage : $0 <dossier_xml> <dossier_sortie>"
    echo ""
    echo "Exemple :"
    echo "  $0 ~/tlfi_xml/ ~/lexigraphe/data/"
    exit 1
fi

XML_DIR="$1"
OUTPUT_DIR="$2"

# Vérifications
if [ ! -d "$XML_DIR" ]; then
    echo "❌ Dossier XML introuvable : $XML_DIR"
    exit 1
fi

if [ ! -f "$CONVERTER" ]; then
    echo "❌ Script de conversion introuvable : $CONVERTER"
    exit 1
fi

# Créer le dossier de sortie
mkdir -p "$OUTPUT_DIR"

# Dossier temporaire pour les JSON individuels
JSON_TMP="$OUTPUT_DIR/json_parts"
mkdir -p "$JSON_TMP"

# === ÉTAPE 1 : CONVERSION XML → JSON ===
echo "════════════════════════════════════════════════════════════"
echo "  ÉTAPE 1 : Conversion des fichiers XML"
echo "════════════════════════════════════════════════════════════"
echo ""

# Compter les fichiers XML
XML_COUNT=$(find "$XML_DIR" -maxdepth 1 -name "*.xml" | wc -l)
echo "📁 $XML_COUNT fichiers XML trouvés dans $XML_DIR"
echo ""

# Convertir chaque fichier
CURRENT=0
ERRORS=0

for xml_file in "$XML_DIR"/*.xml; do
    if [ ! -f "$xml_file" ]; then
        continue
    fi
    
    CURRENT=$((CURRENT + 1))
    BASENAME=$(basename "$xml_file" .xml)
    JSON_FILE="$JSON_TMP/${BASENAME}.json"
    
    echo -n "[$CURRENT/$XML_COUNT] $BASENAME.xml → "
    
    if python3 "$CONVERTER" "$xml_file" "$JSON_FILE" 2>/dev/null; then
        # Compter les entrées
        ENTRIES=$(python3 -c "import json; d=json.load(open('$JSON_FILE')); print(len(d.get('entries', {})))" 2>/dev/null || echo "?")
        echo "$ENTRIES entrées ✓"
    else
        echo "ERREUR ✗"
        ERRORS=$((ERRORS + 1))
    fi
done

echo ""
echo "✓ Conversion terminée : $((CURRENT - ERRORS))/$CURRENT fichiers convertis"

if [ $ERRORS -gt 0 ]; then
    echo "⚠️  $ERRORS erreurs de conversion"
fi

# === ÉTAPE 2 : FUSION DES JSON ===
echo ""
echo "════════════════════════════════════════════════════════════"
echo "  ÉTAPE 2 : Fusion des fichiers JSON"
echo "════════════════════════════════════════════════════════════"
echo ""

OUTPUT_FILE="$OUTPUT_DIR/tlfi_complet.json"

# Utiliser le mode streaming pour économiser la mémoire
python3 "$MERGER" "$JSON_TMP" "$OUTPUT_FILE" --streaming

echo ""
echo "════════════════════════════════════════════════════════════"
echo "  TERMINÉ"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "📄 Fichier fusionné : $OUTPUT_FILE"
echo "📊 Taille : $(du -h "$OUTPUT_FILE" | cut -f1)"
echo ""
echo "💡 Vous pouvez supprimer les fichiers intermédiaires :"
echo "   rm -rf $JSON_TMP"
echo ""
echo "📋 Pour vérifier :"
echo "   python3 -c \"import json; d=json.load(open('$OUTPUT_FILE')); print(f'{len(d[\\\"entries\\\"])} entrées')\""
