#!/usr/bin/env python3
"""
Fusion des fichiers JSON du TLFi

Fusionne plusieurs fichiers JSON (produits par tlfi_to_json_v2.py) 
en un seul fichier, de manière incrémentale pour éviter les problèmes de mémoire.

Usage :
    python merge_tlfi_json.py /chemin/vers/json/ output.json
    python merge_tlfi_json.py /chemin/vers/json/*.json output.json
"""

import json
import sys
from pathlib import Path
from typing import Iterator, Dict, Any
import argparse


def iter_json_files(input_path: str) -> Iterator[Path]:
    """Itère sur les fichiers JSON à traiter."""
    path = Path(input_path)
    
    if path.is_dir():
        # Dossier : tous les .json dedans
        yield from sorted(path.glob("*.json"))
    elif path.is_file():
        # Fichier unique
        yield path
    elif "*" in input_path:
        # Pattern glob
        from glob import glob
        for f in sorted(glob(input_path)):
            yield Path(f)
    else:
        raise FileNotFoundError(f"Chemin introuvable : {input_path}")


def load_json_entries(json_path: Path) -> Dict[str, Any]:
    """Charge les entrées d'un fichier JSON."""
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data.get('entries', {})


def merge_json_files_memory(json_files: list, output_path: Path) -> dict:
    """
    Fusion en mémoire (simple mais gourmand).
    Utilisable si la somme des JSON tient en RAM.
    """
    all_entries = {}
    total_files = len(json_files)
    
    for i, json_file in enumerate(json_files, 1):
        print(f"  [{i}/{total_files}] {json_file.name}...", end=" ", flush=True)
        
        entries = load_json_entries(json_file)
        
        # Gérer les doublons (homographes)
        for key, value in entries.items():
            if key in all_entries:
                # Clé déjà existante → ajouter un suffixe
                n = 1
                new_key = f"{key}_{n}"
                while new_key in all_entries:
                    n += 1
                    new_key = f"{key}_{n}"
                all_entries[new_key] = value
                print(f"(doublon: {key} → {new_key})", end=" ")
            else:
                all_entries[key] = value
        
        print(f"{len(entries)} entrées")
    
    # Écrire le résultat
    result = {
        "metadata": {
            "source": "TLFi (ATILF)",
            "entries_count": len(all_entries),
            "format_version": "2.0",
            "merged_from": len(json_files)
        },
        "entries": all_entries
    }
    
    print(f"\n💾 Écriture de {output_path}...")
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False)
    
    return result


def merge_json_files_streaming(json_files: list, output_path: Path):
    """
    Fusion en streaming (économe en mémoire).
    Écrit directement dans le fichier de sortie sans tout charger en RAM.
    """
    total_files = len(json_files)
    entries_count = 0
    seen_keys = set()
    
    with open(output_path, 'w', encoding='utf-8') as out:
        # Écrire le début du JSON
        out.write('{\n  "metadata": {\n')
        out.write('    "source": "TLFi (ATILF)",\n')
        out.write('    "format_version": "2.0",\n')
        out.write(f'    "merged_from": {total_files}\n')
        out.write('  },\n')
        out.write('  "entries": {\n')
        
        first_entry = True
        
        for i, json_file in enumerate(json_files, 1):
            print(f"  [{i}/{total_files}] {json_file.name}...", end=" ", flush=True)
            
            entries = load_json_entries(json_file)
            file_count = 0
            
            for key, value in entries.items():
                # Gérer les doublons
                original_key = key
                if key in seen_keys:
                    n = 1
                    while f"{key}_{n}" in seen_keys:
                        n += 1
                    key = f"{key}_{n}"
                
                seen_keys.add(key)
                
                # Écrire l'entrée
                if not first_entry:
                    out.write(',\n')
                first_entry = False
                
                # Sérialiser la valeur
                value_json = json.dumps(value, ensure_ascii=False)
                out.write(f'    "{key}": {value_json}')
                
                entries_count += 1
                file_count += 1
            
            print(f"{file_count} entrées")
        
        # Fermer le JSON
        out.write('\n  }\n')
        out.write('}\n')
    
    # Mettre à jour le count dans les métadonnées (réécriture du début)
    # Note : en mode streaming pur, on ne peut pas le faire proprement
    # On affiche juste le total
    print(f"\n✓ Total : {entries_count} entrées fusionnées")
    
    return entries_count


def main():
    parser = argparse.ArgumentParser(
        description="Fusionne plusieurs fichiers JSON du TLFi en un seul."
    )
    parser.add_argument(
        "input",
        help="Dossier contenant les JSON, ou pattern glob (ex: data/*.json)"
    )
    parser.add_argument(
        "output",
        help="Fichier JSON de sortie"
    )
    parser.add_argument(
        "--streaming",
        action="store_true",
        help="Mode streaming (économe en mémoire, recommandé pour gros volumes)"
    )
    parser.add_argument(
        "--indent",
        action="store_true",
        help="Indenter le JSON de sortie (plus lisible mais plus gros)"
    )
    
    args = parser.parse_args()
    
    # Collecter les fichiers
    json_files = list(iter_json_files(args.input))
    
    if not json_files:
        print("❌ Aucun fichier JSON trouvé.")
        sys.exit(1)
    
    print(f"📁 {len(json_files)} fichiers JSON à fusionner\n")
    
    output_path = Path(args.output)
    
    if args.streaming:
        print("🔄 Mode streaming (économe en mémoire)\n")
        merge_json_files_streaming(json_files, output_path)
    else:
        print("🔄 Mode mémoire (plus rapide)\n")
        result = merge_json_files_memory(json_files, output_path)
        print(f"✓ {result['metadata']['entries_count']} entrées fusionnées")
    
    # Taille du fichier
    size_mb = output_path.stat().st_size / (1024 * 1024)
    print(f"📊 Taille du fichier : {size_mb:.1f} Mo")


if __name__ == "__main__":
    main()
