#!/usr/bin/env python3
"""
Convertisseur TLFi XML → JSON pour LexiGraphe

Extrait les informations essentielles des entrées TLFi :
- Mot-vedette (lemme)
- Catégorie grammaticale
- Domaine(s)
- Définition(s)
- Dérivés morphologiques
- Étymologie (racines)

Produit un fichier JSON optimisé pour le jeu "Chaîne sémantique".
"""

import json
import re
from pathlib import Path
from lxml import etree
from typing import Optional
from dataclasses import dataclass, asdict


@dataclass
class TLFiEntry:
    """Représentation simplifiée d'une entrée TLFi."""
    id: str
    lemma: str
    pos: str  # Part of speech
    domains: list[str]
    definitions: list[str]
    examples: list[str]
    derivatives: list[str]
    etymology_roots: list[str]
    
    def to_dict(self) -> dict:
        return asdict(self)


def clean_text(text: str) -> str:
    """Nettoie le texte extrait du XML."""
    if not text:
        return ""
    # Supprimer les espaces multiples
    text = re.sub(r'\s+', ' ', text)
    # Supprimer les espaces en début/fin
    text = text.strip()
    return text


def extract_text_recursive(element) -> str:
    """Extrait tout le texte d'un élément et ses descendants."""
    texts = []
    if element.text:
        texts.append(element.text)
    for child in element:
        texts.append(extract_text_recursive(child))
        if child.tail:
            texts.append(child.tail)
    return ''.join(texts)


def parse_entry(article: etree._Element) -> Optional[TLFiEntry]:
    """Parse une entrée <article> du TLFi."""
    
    entry_id = article.get('id', '')
    
    # Mot-vedette
    lemma_elem = article.find('.//vedette//mot')
    if lemma_elem is None:
        return None
    lemma = clean_text(extract_text_recursive(lemma_elem))
    # Nettoyer les parenthèses (ex: "LIGNIFIER (SE)" → "LIGNIFIER")
    lemma = re.sub(r'\s*\([^)]*\)\s*', '', lemma).strip()
    
    # Catégorie grammaticale
    pos_elem = article.find('.//partieDuDiscours')
    pos = clean_text(extract_text_recursive(pos_elem)) if pos_elem is not None else ""
    
    # Domaines
    domains = []
    for usage in article.findall('.//usage[@type="domaine"]'):
        domain_text = clean_text(extract_text_recursive(usage))
        if domain_text:
            domains.append(domain_text.rstrip('.'))
    
    # Définitions
    definitions = []
    for defn in article.findall('.//definition/contenu'):
        def_text = clean_text(extract_text_recursive(defn))
        if def_text and len(def_text) > 5:  # Filtrer les définitions vides
            definitions.append(def_text)
    
    # Exemples (premiers 3 pour limiter la taille)
    examples = []
    for exemple in article.findall('.//exemple/contenu')[:3]:
        ex_text = clean_text(extract_text_recursive(exemple))
        if ex_text and len(ex_text) > 10:
            # Tronquer les exemples trop longs
            if len(ex_text) > 200:
                ex_text = ex_text[:200] + "..."
            examples.append(ex_text)
    
    # Dérivés
    derivatives = []
    for derived in article.findall('.//article[@type="dérivé"]//vedette//mot'):
        deriv_text = clean_text(extract_text_recursive(derived))
        deriv_text = re.sub(r'\s*\([^)]*\)\s*', '', deriv_text).strip()
        deriv_text = re.sub(r',-.*$', '', deriv_text).strip()  # "Lignifié, -ée" → "Lignifié"
        if deriv_text and deriv_text != lemma:
            derivatives.append(deriv_text.upper())
    
    # Racines étymologiques (extraction simplifiée)
    etymology_roots = []
    etym_elem = article.find('.//rubrique[@type="étymologie"]')
    if etym_elem is not None:
        etym_text = extract_text_recursive(etym_elem)
        # Chercher les mots latins/grecs entre italiques ou après "lat."/"gr."
        latin_matches = re.findall(r'lat\.\s*(\w+)', etym_text, re.IGNORECASE)
        greek_matches = re.findall(r'gr\.\s*(\w+)', etym_text, re.IGNORECASE)
        etymology_roots = list(set(latin_matches + greek_matches))
    
    return TLFiEntry(
        id=entry_id,
        lemma=lemma,
        pos=pos,
        domains=domains,
        definitions=definitions,
        examples=examples,
        derivatives=derivatives,
        etymology_roots=etymology_roots
    )


def convert_tlfi_file(xml_path: Path, output_path: Path) -> dict:
    """Convertit un fichier XML TLFi complet en JSON."""
    
    print(f"Parsing {xml_path}...")
    tree = etree.parse(str(xml_path))
    root = tree.getroot()
    
    entries = {}
    
    # Trouver tous les articles (entrées principales)
    for article in root.findall('.//article'):
        entry = parse_entry(article)
        if entry and entry.lemma:
            # Utiliser le lemme en majuscules comme clé
            key = entry.lemma.upper()
            # Gérer les homographes
            if key in entries:
                key = f"{key}_{len([k for k in entries if k.startswith(key)])}"
            entries[key] = entry.to_dict()
    
    print(f"Extracted {len(entries)} entries")
    
    # Sauvegarder en JSON
    result = {
        "metadata": {
            "source": "TLFi (ATILF)",
            "entries_count": len(entries),
            "format_version": "1.0"
        },
        "entries": entries
    }
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print(f"Saved to {output_path}")
    return result


def create_sample_data() -> dict:
    """Crée des données d'exemple pour le prototype (sans fichier TLFi)."""
    
    sample_entries = {
        "LIGNIFIER": {
            "id": "tlfi_lignifier",
            "lemma": "LIGNIFIER",
            "pos": "verbe pronominal",
            "domains": ["BOT."],
            "definitions": ["Se transformer en bois."],
            "examples": ["Les rejets à peine nés fléchissent : tissu herbacé encore, fragile. Et lorsqu'ils se lignifient, mettent des feuilles..."],
            "derivatives": ["LIGNIFIÉ", "LIGNIFICATION"],
            "etymology_roots": ["lignum"]
        },
        "BOIS": {
            "id": "tlfi_bois",
            "lemma": "BOIS",
            "pos": "substantif masculin",
            "domains": ["BOT.", "SYLVIC."],
            "definitions": ["Substance dure et compacte des arbres.", "Étendue de terrain couverte d'arbres."],
            "examples": ["Un meuble en bois de chêne.", "Se promener dans les bois."],
            "derivatives": ["BOISÉ", "BOISEMENT", "BOISER"],
            "etymology_roots": ["boscus"]
        },
        "FORÊT": {
            "id": "tlfi_foret",
            "lemma": "FORÊT",
            "pos": "substantif féminin",
            "domains": ["GÉOGR.", "ÉCOL."],
            "definitions": ["Vaste étendue de terrain couverte d'arbres.", "Ensemble d'arbres couvrant une grande superficie."],
            "examples": ["La forêt amazonienne.", "Se perdre dans la forêt."],
            "derivatives": ["FORESTIER", "FORESTERIE"],
            "etymology_roots": ["forestis"]
        },
        "ARBRE": {
            "id": "tlfi_arbre",
            "lemma": "ARBRE",
            "pos": "substantif masculin",
            "domains": ["BOT."],
            "definitions": ["Végétal ligneux de grande taille dont la tige ne se ramifie qu'à partir d'une certaine hauteur."],
            "examples": ["Un arbre centenaire.", "L'arbre généalogique de la famille."],
            "derivatives": ["ARBRISSEAU", "ARBUSTE", "ARBORÉ"],
            "etymology_roots": ["arbor"]
        },
        "FEUILLE": {
            "id": "tlfi_feuille",
            "lemma": "FEUILLE",
            "pos": "substantif féminin",
            "domains": ["BOT."],
            "definitions": ["Organe végétal, généralement vert et plat, qui naît sur la tige ou les rameaux."],
            "examples": ["Les feuilles tombent en automne.", "Une feuille de papier."],
            "derivatives": ["FEUILLAGE", "FEUILLU", "EFFEUILLER"],
            "etymology_roots": ["folium"]
        },
        "OMBRE": {
            "id": "tlfi_ombre",
            "lemma": "OMBRE",
            "pos": "substantif féminin",
            "domains": ["PHYS.", "FIG."],
            "definitions": ["Zone sombre créée par un corps opaque qui intercepte la lumière.", "Obscurité relative."],
            "examples": ["Se reposer à l'ombre d'un arbre.", "Vivre dans l'ombre."],
            "derivatives": ["OMBRAGER", "OMBRAGÉ", "OMBREUX"],
            "etymology_roots": ["umbra"]
        },
        "LUMIÈRE": {
            "id": "tlfi_lumiere",
            "lemma": "LUMIÈRE",
            "pos": "substantif féminin",
            "domains": ["PHYS.", "FIG."],
            "definitions": ["Rayonnement électromagnétique visible.", "Ce qui éclaire l'esprit."],
            "examples": ["La lumière du soleil.", "Faire la lumière sur une affaire."],
            "derivatives": ["LUMINEUX", "LUMINOSITÉ", "ILLUMINER"],
            "etymology_roots": ["lumen"]
        },
        "SOLEIL": {
            "id": "tlfi_soleil",
            "lemma": "SOLEIL",
            "pos": "substantif masculin",
            "domains": ["ASTRON."],
            "definitions": ["Astre autour duquel gravite la Terre.", "Lumière et chaleur émises par cet astre."],
            "examples": ["Le soleil se lève à l'est.", "Prendre un bain de soleil."],
            "derivatives": ["SOLAIRE", "ENSOLEILLÉ", "ENSOLEILLEMENT"],
            "etymology_roots": ["sol"]
        },
        "CHALEUR": {
            "id": "tlfi_chaleur",
            "lemma": "CHALEUR",
            "pos": "substantif féminin",
            "domains": ["PHYS.", "FIG."],
            "definitions": ["Qualité de ce qui est chaud.", "Température élevée."],
            "examples": ["La chaleur de l'été.", "Parler avec chaleur."],
            "derivatives": ["CHALEUREUX", "CHAUFFER", "RÉCHAUFFER"],
            "etymology_roots": ["calor"]
        },
        "FROID": {
            "id": "tlfi_froid",
            "lemma": "FROID",
            "pos": "substantif masculin / adjectif",
            "domains": ["PHYS.", "FIG."],
            "definitions": ["Température basse.", "Qui est à basse température."],
            "examples": ["Le froid de l'hiver.", "Un accueil froid."],
            "derivatives": ["FROIDEUR", "REFROIDIR", "FROIDURE"],
            "etymology_roots": ["frigidus"]
        },
        "GLACE": {
            "id": "tlfi_glace",
            "lemma": "GLACE",
            "pos": "substantif féminin",
            "domains": ["PHYS."],
            "definitions": ["Eau congelée.", "Miroir."],
            "examples": ["Les glaces du pôle Nord.", "Se regarder dans la glace."],
            "derivatives": ["GLACER", "GLACIAL", "GLACIATION"],
            "etymology_roots": ["glacies"]
        },
        "EAU": {
            "id": "tlfi_eau",
            "lemma": "EAU",
            "pos": "substantif féminin",
            "domains": ["CHIM.", "PHYS."],
            "definitions": ["Liquide incolore, inodore, composé d'hydrogène et d'oxygène."],
            "examples": ["Un verre d'eau.", "L'eau de la rivière."],
            "derivatives": ["AQUEUX", "AQUATIQUE"],
            "etymology_roots": ["aqua"]
        },
        "FRAÎCHEUR": {
            "id": "tlfi_fraicheur",
            "lemma": "FRAÎCHEUR",
            "pos": "substantif féminin",
            "domains": [],
            "definitions": ["Qualité de ce qui est frais.", "Température modérément froide."],
            "examples": ["La fraîcheur du matin.", "La fraîcheur d'un teint."],
            "derivatives": ["FRAIS", "RAFRAÎCHIR"],
            "etymology_roots": []
        },
        "NATURE": {
            "id": "tlfi_nature",
            "lemma": "NATURE",
            "pos": "substantif féminin",
            "domains": ["PHILOS.", "ÉCOL."],
            "definitions": ["Ensemble du monde physique.", "Caractère essentiel d'un être."],
            "examples": ["La beauté de la nature.", "C'est dans sa nature."],
            "derivatives": ["NATUREL", "NATURALISTE", "DÉNATURER"],
            "etymology_roots": ["natura"]
        },
        "VIE": {
            "id": "tlfi_vie",
            "lemma": "VIE",
            "pos": "substantif féminin",
            "domains": ["BIOL.", "PHILOS."],
            "definitions": ["État des organismes animés.", "Existence d'un être humain."],
            "examples": ["La vie sur Terre.", "Mener une vie heureuse."],
            "derivatives": ["VITAL", "VIVANT", "VIVRE"],
            "etymology_roots": ["vita"]
        },
        "MORT": {
            "id": "tlfi_mort",
            "lemma": "MORT",
            "pos": "substantif féminin",
            "domains": ["BIOL.", "PHILOS."],
            "definitions": ["Cessation définitive de la vie.", "État d'un être qui a cessé de vivre."],
            "examples": ["La mort est inévitable.", "Être condamné à mort."],
            "derivatives": ["MORTEL", "MORTALITÉ", "MOURIR"],
            "etymology_roots": ["mors"]
        },
        "TEMPS": {
            "id": "tlfi_temps",
            "lemma": "TEMPS",
            "pos": "substantif masculin",
            "domains": ["PHILOS.", "PHYS.", "MÉTÉO."],
            "definitions": ["Durée dans laquelle se succèdent les événements.", "État de l'atmosphère."],
            "examples": ["Le temps passe vite.", "Quel temps fait-il ?"],
            "derivatives": ["TEMPOREL", "TEMPORAIRE", "CONTEMPORAIN"],
            "etymology_roots": ["tempus"]
        },
        "ESPACE": {
            "id": "tlfi_espace",
            "lemma": "ESPACE",
            "pos": "substantif masculin",
            "domains": ["PHYS.", "GÉOM."],
            "definitions": ["Étendue indéfinie.", "Lieu où se situent les corps."],
            "examples": ["L'exploration de l'espace.", "Manquer d'espace."],
            "derivatives": ["SPATIAL", "ESPACER", "ESPACEMENT"],
            "etymology_roots": ["spatium"]
        },
        "RACINE": {
            "id": "tlfi_racine",
            "lemma": "RACINE",
            "pos": "substantif féminin",
            "domains": ["BOT.", "LING.", "MATH."],
            "definitions": ["Partie souterraine d'un végétal.", "Élément irréductible d'un mot."],
            "examples": ["Les racines de l'arbre.", "La racine carrée de 4 est 2."],
            "derivatives": ["RACINAIRE", "ENRACINER", "DÉRACINER"],
            "etymology_roots": ["radix"]
        },
        "TERRE": {
            "id": "tlfi_terre",
            "lemma": "TERRE",
            "pos": "substantif féminin",
            "domains": ["GÉOGR.", "AGRIC."],
            "definitions": ["Sol sur lequel on marche.", "Planète du système solaire."],
            "examples": ["Cultiver la terre.", "La Terre tourne autour du Soleil."],
            "derivatives": ["TERRESTRE", "TERRAIN", "ENTERRER"],
            "etymology_roots": ["terra"]
        }
    }
    
    return {
        "metadata": {
            "source": "TLFi (échantillon de démonstration)",
            "entries_count": len(sample_entries),
            "format_version": "1.0"
        },
        "entries": sample_entries
    }


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        # Mode conversion de fichier réel
        xml_path = Path(sys.argv[1])
        output_path = Path(sys.argv[2]) if len(sys.argv) > 2 else xml_path.with_suffix('.json')
        convert_tlfi_file(xml_path, output_path)
    else:
        # Mode génération de données d'exemple
        output_path = Path(__file__).parent.parent / "data" / "tlfi_sample.json"
        output_path.parent.mkdir(exist_ok=True)
        result = create_sample_data()
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"Sample data saved to {output_path}")
