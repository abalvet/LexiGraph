#!/usr/bin/env python3
"""
Convertisseur TLFi XML → JSON (version 2.0)

Préserve la structure hiérarchique des sens :
- Sens principaux (A., B., C.)
- Sous-sens (I., II., III. ou 1., 2., 3.)
- Emplois spécifiques (Fig., P. ext., P. compar., etc.)

Chaque sens conserve ses exemples et indicateurs d'emploi.
"""

import json
import re
from pathlib import Path
from lxml import etree
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field, asdict


# ========================================
# STRUCTURES DE DONNÉES
# ========================================

@dataclass
class Example:
    """Un exemple d'emploi avec sa source."""
    text: str
    author: str = ""
    title: str = ""
    date: str = ""
    type: str = ""  # "enchainé", "détaché"
    
    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v}


@dataclass
class Sense:
    """Un sens ou sous-sens avec sa définition et ses exemples."""
    id: str = ""
    number: str = ""  # "A.", "I.", "1.", "a)", etc.
    definition: str = ""
    usage_label: str = ""  # "Fig.", "P. ext.", "BOT.", etc.
    domain: str = ""
    examples: List[Example] = field(default_factory=list)
    subsenses: List['Sense'] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        result = {}
        if self.number:
            result['number'] = self.number
        if self.definition:
            result['definition'] = self.definition
        if self.usage_label:
            result['usage'] = self.usage_label
        if self.domain:
            result['domain'] = self.domain
        if self.examples:
            result['examples'] = [ex.to_dict() for ex in self.examples]
        if self.subsenses:
            result['subsenses'] = [s.to_dict() for s in self.subsenses]
        return result


@dataclass 
class TLFiEntry:
    """Représentation complète d'une entrée TLFi."""
    id: str
    lemma: str
    pos: str
    senses: List[Sense] = field(default_factory=list)
    derivatives: List[Dict] = field(default_factory=list)
    etymology: str = ""
    etymology_roots: List[str] = field(default_factory=list)
    pronunciation: str = ""
    
    def to_dict(self) -> dict:
        result = {
            'id': self.id,
            'lemma': self.lemma,
            'pos': self.pos,
        }
        if self.senses:
            result['senses'] = [s.to_dict() for s in self.senses]
        if self.derivatives:
            result['derivatives'] = self.derivatives
        if self.etymology:
            result['etymology'] = self.etymology
        if self.etymology_roots:
            result['etymology_roots'] = self.etymology_roots
        if self.pronunciation:
            result['pronunciation'] = self.pronunciation
        return result
    
    def get_all_definitions(self) -> List[str]:
        """Retourne toutes les définitions à plat (pour compatibilité)."""
        defs = []
        def collect(sense):
            if sense.definition:
                defs.append(sense.definition)
            for sub in sense.subsenses:
                collect(sub)
        for s in self.senses:
            collect(s)
        return defs
    
    def get_all_domains(self) -> List[str]:
        """Retourne tous les domaines mentionnés."""
        domains = set()
        def collect(sense):
            if sense.domain:
                domains.add(sense.domain)
            for sub in sense.subsenses:
                collect(sub)
        for s in self.senses:
            collect(s)
        return list(domains)


# ========================================
# FONCTIONS DE PARSING
# ========================================

def clean_text(text: str) -> str:
    """Nettoie le texte extrait du XML."""
    if not text:
        return ""
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    # Supprimer les parenthèses vides ou les séparateurs orphelins
    text = re.sub(r'\(\s*\)', '', text)
    text = re.sub(r'^\s*[,.:;]\s*', '', text)
    text = re.sub(r'\s*[,.:;]\s*$', '', text)
    return text.strip()


def extract_text_recursive(element, exclude_tags=None) -> str:
    """Extrait le texte d'un élément et ses descendants."""
    if element is None:
        return ""
    exclude_tags = exclude_tags or []
    texts = []
    if element.text:
        texts.append(element.text)
    for child in element:
        if child.tag not in exclude_tags:
            texts.append(extract_text_recursive(child, exclude_tags))
        if child.tail:
            texts.append(child.tail)
    return ''.join(texts)


def parse_example(exemple_elem) -> Optional[Example]:
    """Parse un élément <exemple>."""
    if exemple_elem is None:
        return None
    
    # Texte de l'exemple
    contenu = exemple_elem.find('contenu')
    text = clean_text(extract_text_recursive(contenu)) if contenu is not None else ""
    
    if not text or len(text) < 5:
        return None
    
    # Métadonnées bibliographiques
    biblio = exemple_elem.find('bibliographie')
    author = ""
    title = ""
    date = ""
    
    if biblio is not None:
        author_elem = biblio.find('auteur')
        if author_elem is not None:
            author = clean_text(extract_text_recursive(author_elem))
        
        title_elem = biblio.find('titre')
        if title_elem is not None:
            title = clean_text(extract_text_recursive(title_elem))
        
        date_elem = biblio.find('date')
        if date_elem is not None:
            date = clean_text(extract_text_recursive(date_elem))
    
    ex_type = exemple_elem.get('type', '')
    
    return Example(
        text=text[:500],  # Limiter la longueur
        author=author,
        title=title,
        date=date,
        type=ex_type
    )


def parse_bloc(bloc_elem) -> Sense:
    """Parse un élément <bloc> contenant définition et exemples."""
    sense = Sense()
    
    # Domaine
    domain_elem = bloc_elem.find('usage[@type="domaine"]')
    if domain_elem is not None:
        sense.domain = clean_text(extract_text_recursive(domain_elem)).rstrip('.')
    
    # Indicateur d'emploi (Fig., P. ext., etc.)
    usage_elem = bloc_elem.find('usage[@type="indicateurEmploi"]')
    if usage_elem is not None:
        sense.usage_label = clean_text(extract_text_recursive(usage_elem))
    
    # Définition
    def_elem = bloc_elem.find('definition/contenu')
    if def_elem is not None:
        sense.definition = clean_text(extract_text_recursive(def_elem))
    
    # Exemples
    for exemple in bloc_elem.findall('exemple'):
        ex = parse_example(exemple)
        if ex:
            sense.examples.append(ex)
    
    # Syntagmes illustratifs (parfois contiennent des exemples)
    for syntagme in bloc_elem.findall('syntagme[@type="illustratif"]'):
        syn_text = clean_text(extract_text_recursive(syntagme.find('contenu')))
        if syn_text and len(syn_text) > 10:
            sense.examples.append(Example(text=syn_text, type='syntagme'))
    
    return sense


def parse_structure(structure_elem, depth=0) -> List[Sense]:
    """Parse récursivement une <structure> et ses sous-structures."""
    senses = []
    
    # Récupérer le numéro de niveau si présent
    struct_type = structure_elem.get('type', '')
    level_number = structure_elem.get('n', '')
    
    # Traiter les blocs directs de cette structure
    current_sense = None
    
    for child in structure_elem:
        if child.tag == 'contenu' and struct_type == 'numérotation':
            # C'est juste l'affichage du numéro, on l'ignore
            continue
            
        elif child.tag == 'bloc':
            sense = parse_bloc(child)
            sense.number = level_number
            
            if current_sense is None:
                current_sense = sense
            else:
                # Plusieurs blocs au même niveau → les fusionner ou créer des sous-sens
                if sense.definition:
                    current_sense.subsenses.append(sense)
                else:
                    # Bloc sans définition (juste des exemples) → ajouter à current
                    current_sense.examples.extend(sense.examples)
        
        elif child.tag == 'structure':
            # Structure imbriquée → sous-sens
            subsenses = parse_structure(child, depth + 1)
            
            if current_sense is not None:
                current_sense.subsenses.extend(subsenses)
            else:
                # Pas de bloc parent, les sous-sens deviennent des sens principaux
                senses.extend(subsenses)
    
    if current_sense is not None:
        senses.append(current_sense)
    
    return senses


def parse_synchronie(rubrique_elem) -> List[Sense]:
    """Parse la rubrique synchronie (sens actuels du mot)."""
    senses = []
    
    for child in rubrique_elem:
        if child.tag == 'structure':
            senses.extend(parse_structure(child))
        elif child.tag == 'bloc':
            # Bloc directement sous synchronie (mot avec un seul sens)
            sense = parse_bloc(child)
            if sense.definition or sense.examples:
                senses.append(sense)
    
    return senses


def parse_derivatives(rubrique_elem) -> List[Dict]:
    """Parse les dérivés (DÉR., REM.)."""
    derivatives = []
    
    for article in rubrique_elem.findall('.//article[@type="dérivé"]'):
        deriv = {}
        
        # Mot-vedette du dérivé
        mot_elem = article.find('.//vedette//mot')
        if mot_elem is not None:
            lemma = clean_text(extract_text_recursive(mot_elem))
            # Nettoyer : "Lignifié, -ée" → "LIGNIFIÉ"
            lemma = re.sub(r',-.*$', '', lemma).strip()
            lemma = re.sub(r'\s*\([^)]*\)\s*', '', lemma).strip()
            deriv['lemma'] = lemma.upper()
        
        # Catégorie grammaticale
        pos_elem = article.find('.//partieDuDiscours')
        if pos_elem is not None:
            deriv['pos'] = clean_text(extract_text_recursive(pos_elem))
        
        # Définition du dérivé
        def_elem = article.find('.//definition/contenu')
        if def_elem is not None:
            deriv['definition'] = clean_text(extract_text_recursive(def_elem))
        
        if deriv.get('lemma'):
            derivatives.append(deriv)
    
    return derivatives


def parse_etymology(rubrique_elem) -> tuple:
    """Parse l'étymologie et extrait les racines."""
    full_text = clean_text(extract_text_recursive(rubrique_elem))
    
    # Extraire les racines latines et grecques
    roots = []
    
    # Mots latins (après "lat." ou en italique avant "« ... »")
    latin_matches = re.findall(r'lat\.\s*([a-zA-Z]+)', full_text, re.IGNORECASE)
    roots.extend(latin_matches)
    
    # Mots grecs
    greek_matches = re.findall(r'gr\.\s*([a-zA-Z]+)', full_text, re.IGNORECASE)
    roots.extend(greek_matches)
    
    # Mots entre guillemets après "du" ou "de"
    quoted = re.findall(r'(?:du|de)\s+([a-zA-Z]+)\s+[«"]', full_text)
    roots.extend(quoted)
    
    return full_text, list(set(roots))


def parse_entry(article: etree._Element) -> Optional[TLFiEntry]:
    """Parse une entrée <article> complète du TLFi."""
    
    entry_id = article.get('id', '')
    
    # === MOT-VEDETTE ===
    vedette = article.find('vedette')
    if vedette is None:
        return None
    
    mot_elem = vedette.find('.//mot')
    if mot_elem is None:
        return None
    
    lemma = clean_text(extract_text_recursive(mot_elem))
    lemma = re.sub(r'\s*\([^)]*\)\s*', '', lemma).strip()  # "(SE)" etc.
    
    if not lemma:
        return None
    
    # Catégorie grammaticale
    pos_elem = vedette.find('.//partieDuDiscours')
    pos = clean_text(extract_text_recursive(pos_elem)) if pos_elem is not None else ""
    
    # === SENS (SYNCHRONIE) ===
    senses = []
    sync_rubrique = article.find('rubrique[@type="synchronie"]')
    if sync_rubrique is not None:
        senses = parse_synchronie(sync_rubrique)
    
    # === DÉRIVÉS ===
    derivatives = []
    for rubrique in article.findall('rubrique[@type="dérivés"]'):
        derivatives.extend(parse_derivatives(rubrique))
    for rubrique in article.findall('rubrique[@type="remarque"]'):
        derivatives.extend(parse_derivatives(rubrique))
    
    # === ÉTYMOLOGIE ===
    etymology = ""
    etymology_roots = []
    etym_rubrique = article.find('rubrique[@type="étymologie"]')
    if etym_rubrique is not None:
        etymology, etymology_roots = parse_etymology(etym_rubrique)
    
    # === PRONONCIATION ===
    pronunciation = ""
    pron_rubrique = article.find('rubrique[@type="prononciation"]')
    if pron_rubrique is not None:
        # Extraire juste la transcription phonétique si possible
        pron_text = extract_text_recursive(pron_rubrique)
        # Chercher les crochets phonétiques [...]
        pron_match = re.search(r'\[([^\]]+)\]', pron_text)
        if pron_match:
            pronunciation = pron_match.group(1)
    
    return TLFiEntry(
        id=entry_id,
        lemma=lemma.upper(),
        pos=pos,
        senses=senses,
        derivatives=derivatives,
        etymology=etymology[:500] if etymology else "",
        etymology_roots=etymology_roots,
        pronunciation=pronunciation
    )


# ========================================
# CONVERSION FICHIER COMPLET
# ========================================

def convert_tlfi_file(xml_path: Path, output_path: Path) -> dict:
    """Convertit un fichier XML TLFi complet en JSON."""
    
    print(f"📖 Parsing {xml_path}...")
    
    # Parser le XML
    parser = etree.XMLParser(recover=True, encoding='utf-8')
    tree = etree.parse(str(xml_path), parser)
    root = tree.getroot()
    
    entries = {}
    errors = []
    
    # Trouver tous les articles
    articles = root.findall('.//article')
    total = len(articles)
    
    for i, article in enumerate(articles):
        if (i + 1) % 1000 == 0:
            print(f"  Progression : {i + 1}/{total}")
        
        try:
            entry = parse_entry(article)
            if entry and entry.lemma:
                key = entry.lemma
                # Gérer les homographes
                if key in entries:
                    n = 1
                    while f"{key}_{n}" in entries:
                        n += 1
                    key = f"{key}_{n}"
                entries[key] = entry.to_dict()
        except Exception as e:
            errors.append(f"Erreur article {article.get('id', '?')}: {e}")
    
    print(f"✓ {len(entries)} entrées extraites")
    if errors:
        print(f"⚠ {len(errors)} erreurs (voir le log)")
    
    # Construire le résultat
    result = {
        "metadata": {
            "source": "TLFi (ATILF)",
            "entries_count": len(entries),
            "format_version": "2.0",
            "structure": "hierarchical"
        },
        "entries": entries
    }
    
    # Sauvegarder
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print(f"💾 Sauvegardé dans {output_path}")
    
    # Log des erreurs si présentes
    if errors:
        error_log = output_path.with_suffix('.errors.txt')
        with open(error_log, 'w', encoding='utf-8') as f:
            f.write('\n'.join(errors))
        print(f"📋 Erreurs enregistrées dans {error_log}")
    
    return result


# ========================================
# DONNÉES D'EXEMPLE
# ========================================

def create_sample_data() -> dict:
    """Crée des données d'exemple avec structure hiérarchique."""
    
    sample_entries = {
        "LIMER": {
            "id": "tlfi_limer",
            "lemma": "LIMER",
            "pos": "verbe transitif",
            "senses": [
                {
                    "number": "A. —",
                    "definition": "Polir, entamer avec une lime.",
                    "examples": [
                        {
                            "text": "Limer les dents d'une scie pour l'affûter.",
                            "type": "syntagme"
                        }
                    ],
                    "subsenses": [
                        {
                            "definition": "",
                            "examples": [
                                {
                                    "text": "Cisaillez les bords très doucement pour qu'ils ne se brisent pas, puis vous limez avec une lime à ongles pour adoucir les angles",
                                    "author": "Rousset",
                                    "title": "Trav. pts matér.",
                                    "date": "1928"
                                },
                                {
                                    "text": "elle fit passer une lime. Un des barreaux de fer de la petite fenêtre de la prison fut silencieusement limé et remis à sa place.",
                                    "author": "Lamart.",
                                    "title": "Confid.",
                                    "date": "1849"
                                }
                            ]
                        }
                    ]
                },
                {
                    "number": "B. —",
                    "usage": "Fig.",
                    "definition": "Travailler avec soin, perfectionner minutieusement.",
                    "examples": [
                        {
                            "text": "Limer ses vers, son style.",
                            "type": "syntagme"
                        }
                    ]
                }
            ],
            "derivatives": [
                {"lemma": "LIMEUR", "pos": "substantif masculin"},
                {"lemma": "LIMAILLE", "pos": "substantif féminin", "definition": "Parcelles de métal détachées par la lime."}
            ],
            "etymology_roots": ["limare"]
        },
        "LIGNIFIER": {
            "id": "tlfi_lignifier",
            "lemma": "LIGNIFIER",
            "pos": "verbe pronominal",
            "senses": [
                {
                    "domain": "BOT.",
                    "definition": "Se transformer en bois.",
                    "examples": [
                        {
                            "text": "Les rejets à peine nés fléchissent : tissu herbacé encore, fragile, inconsistant au possible. Et lorsqu'ils se lignifient, mettent des feuilles, celles-ci sortent chétives, décolorées",
                            "author": "Pesquidoux",
                            "title": "Livre raison",
                            "date": "1925"
                        }
                    ]
                }
            ],
            "derivatives": [
                {
                    "lemma": "LIGNIFIÉ",
                    "pos": "participe passé et adjectif",
                    "definition": "Qui a pris les caractères, l'aspect du bois."
                },
                {
                    "lemma": "LIGNIFICATION",
                    "pos": "substantif féminin",
                    "definition": "Processus par lequel les membranes de certaines cellules végétales se transforment en bois."
                }
            ],
            "etymology": "Composé de ligni-, élément tiré du lat. lignum « bois », et de l'élément formant verbal -fier.",
            "etymology_roots": ["lignum"],
            "pronunciation": "liɲifje"
        },
        "GLACE": {
            "id": "tlfi_glace",
            "lemma": "GLACE",
            "pos": "substantif féminin",
            "senses": [
                {
                    "number": "I.",
                    "definition": "Eau congelée, solidifiée par le froid.",
                    "examples": [
                        {"text": "Les glaces du pôle Nord.", "type": "syntagme"}
                    ],
                    "subsenses": [
                        {
                            "number": "1.",
                            "definition": "Eau à l'état solide dans la nature.",
                            "examples": [
                                {"text": "La banquise est formée de glace de mer."}
                            ]
                        },
                        {
                            "number": "2.",
                            "definition": "Glaçon, morceau de glace.",
                            "examples": [
                                {"text": "Mettre des glaces dans un verre."}
                            ]
                        }
                    ]
                },
                {
                    "number": "II.",
                    "definition": "Plaque de verre ou de cristal.",
                    "subsenses": [
                        {
                            "number": "1.",
                            "definition": "Miroir.",
                            "examples": [
                                {"text": "Se regarder dans la glace."}
                            ]
                        },
                        {
                            "number": "2.",
                            "definition": "Vitre d'une voiture.",
                            "examples": [
                                {"text": "Baisser la glace de la portière."}
                            ]
                        }
                    ]
                },
                {
                    "number": "III.",
                    "definition": "Préparation glacée, crème glacée.",
                    "examples": [
                        {"text": "Une glace à la vanille."}
                    ]
                }
            ],
            "derivatives": [
                {"lemma": "GLACER", "pos": "verbe"},
                {"lemma": "GLACIAL", "pos": "adjectif"},
                {"lemma": "GLACIATION", "pos": "substantif féminin"}
            ],
            "etymology_roots": ["glacies"]
        }
    }
    
    # Ajouter les autres mots (version simplifiée pour le jeu)
    simple_words = {
        "BOIS": {"definition": "Substance dure et compacte des arbres.", "related": ["FORÊT", "ARBRE"]},
        "FORÊT": {"definition": "Vaste étendue de terrain couverte d'arbres.", "related": ["BOIS", "NATURE"]},
        "ARBRE": {"definition": "Végétal ligneux de grande taille.", "related": ["FORÊT", "FEUILLE", "RACINE"]},
        "FEUILLE": {"definition": "Organe végétal, généralement vert et plat.", "related": ["ARBRE", "VERT"]},
        "OMBRE": {"definition": "Zone sombre créée par un corps opaque.", "related": ["LUMIÈRE", "FRAÎCHEUR"]},
        "LUMIÈRE": {"definition": "Rayonnement électromagnétique visible.", "related": ["SOLEIL", "OMBRE"]},
        "SOLEIL": {"definition": "Astre autour duquel gravite la Terre.", "related": ["LUMIÈRE", "CHALEUR"]},
        "CHALEUR": {"definition": "Qualité de ce qui est chaud.", "related": ["FROID", "SOLEIL"]},
        "FROID": {"definition": "Température basse.", "related": ["CHALEUR", "GLACE", "HIVER"]},
        "EAU": {"definition": "Liquide composé d'hydrogène et d'oxygène.", "related": ["GLACE", "RIVIÈRE"]},
        "FRAÎCHEUR": {"definition": "Qualité de ce qui est frais.", "related": ["FROID", "OMBRE"]},
        "NATURE": {"definition": "Ensemble du monde physique.", "related": ["FORÊT", "TERRE"]},
        "RACINE": {"definition": "Partie souterraine d'un végétal.", "related": ["ARBRE", "TERRE"]},
        "TERRE": {"definition": "Sol sur lequel on marche.", "related": ["RACINE", "NATURE"]},
        "HIVER": {"definition": "Saison la plus froide de l'année.", "related": ["FROID", "NEIGE"]},
        "NEIGE": {"definition": "Eau congelée qui tombe en flocons.", "related": ["GLACE", "HIVER"]},
    }
    
    for word, data in simple_words.items():
        if word not in sample_entries:
            sample_entries[word] = {
                "id": f"tlfi_{word.lower()}",
                "lemma": word,
                "pos": "substantif",
                "senses": [{"definition": data["definition"]}]
            }
    
    return {
        "metadata": {
            "source": "TLFi (échantillon de démonstration)",
            "entries_count": len(sample_entries),
            "format_version": "2.0",
            "structure": "hierarchical"
        },
        "entries": sample_entries
    }


# ========================================
# UTILITAIRES
# ========================================

def flatten_entry(entry: dict) -> dict:
    """Convertit une entrée hiérarchique en format plat (compatibilité v1)."""
    flat = {
        "id": entry.get("id", ""),
        "lemma": entry.get("lemma", ""),
        "pos": entry.get("pos", ""),
        "definitions": [],
        "examples": [],
        "domains": [],
        "derivatives": [d.get("lemma", "") for d in entry.get("derivatives", [])],
        "etymology_roots": entry.get("etymology_roots", [])
    }
    
    def collect_sense(sense):
        if sense.get("definition"):
            flat["definitions"].append(sense["definition"])
        if sense.get("domain"):
            flat["domains"].append(sense["domain"])
        for ex in sense.get("examples", []):
            if ex.get("text"):
                flat["examples"].append(ex["text"])
        for sub in sense.get("subsenses", []):
            collect_sense(sub)
    
    for sense in entry.get("senses", []):
        collect_sense(sense)
    
    return flat


def convert_to_flat_format(hierarchical_data: dict) -> dict:
    """Convertit tout le fichier en format plat v1."""
    flat_entries = {}
    for key, entry in hierarchical_data.get("entries", {}).items():
        flat_entries[key] = flatten_entry(entry)
    
    return {
        "metadata": {
            **hierarchical_data.get("metadata", {}),
            "format_version": "1.0",
            "structure": "flat"
        },
        "entries": flat_entries
    }


# ========================================
# MAIN
# ========================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        # Mode conversion de fichier réel
        xml_path = Path(sys.argv[1])
        output_path = Path(sys.argv[2]) if len(sys.argv) > 2 else xml_path.with_suffix('.json')
        
        result = convert_tlfi_file(xml_path, output_path)
        
        # Optionnel : créer aussi une version plate
        if '--flat' in sys.argv:
            flat_path = output_path.with_stem(output_path.stem + '_flat')
            flat_data = convert_to_flat_format(result)
            with open(flat_path, 'w', encoding='utf-8') as f:
                json.dump(flat_data, f, ensure_ascii=False, indent=2)
            print(f"💾 Version plate sauvegardée dans {flat_path}")
    
    else:
        # Mode génération de données d'exemple
        output_path = Path(__file__).parent.parent / "data" / "tlfi_sample_v2.json"
        output_path.parent.mkdir(exist_ok=True)
        
        result = create_sample_data()
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"✓ Données d'exemple (v2) sauvegardées dans {output_path}")
        
        # Afficher un exemple
        print("\n📋 Exemple d'entrée (GLACE) :")
        print(json.dumps(result["entries"]["GLACE"], ensure_ascii=False, indent=2)[:1000] + "...")
